﻿using System;

abstract class Employee
{
    public string Name { get; set; }
    public Employee(string name)
    {
        Name = name;
    }
    public abstract double CalculateSalary();
}

class Manager : Employee
{
    private double fixedSalary;
    public Manager(string name, double salary) : base(name)
    {
        fixedSalary = salary;
    }
    public override double CalculateSalary()
    {
        return fixedSalary;
    }
}

class Developer : Employee
{
    private double hourlyRate;
    private int hoursWorked;
    public Developer(string name, double rate, int hours) : base(name)
    {
        hourlyRate = rate;
        hoursWorked = hours;
    }
    public override double CalculateSalary()
    {
        return hourlyRate * hoursWorked;
    }
}

class Intern : Employee
{
    public Intern(string name) : base(name) { }
    public override double CalculateSalary()
    {
        return 0; 
    }
}

class Program
{
    static void Main()
    {
        Employee[] employees =
        {
            new Manager("Соня",1700),
            new Developer("Ксюша", 15, 60),
            new Intern("Сергей")
        };

        Console.WriteLine("Список сотрудников и их зарплаты:");
        foreach (var emp in employees)
        {
            Console.WriteLine($"{emp.Name}: {emp.CalculateSalary()} руб.");
        }
    }
}
