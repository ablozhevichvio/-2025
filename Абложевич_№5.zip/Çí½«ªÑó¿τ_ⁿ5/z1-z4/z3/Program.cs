﻿using System;
using System.Linq;

abstract class Animal
{
    public string Name { get; set; }
    public Animal(string name)
    {
        Name = name;
    }
}

interface ICanFly
{
    void Fly();
}

interface ICanSwim
{
    void Swim();
}

class Bird : Animal, ICanFly
{
    public Bird(string name) : base(name) { }
    public void Fly()
    {
        Console.WriteLine($"{Name} летает.");
    }
}

class Fish : Animal, ICanSwim
{
    public Fish(string name) : base(name) { }
    public void Swim()
    {
        Console.WriteLine($"{Name} плавает.");
    }
}

class Program
{
    static void Main()
    {
        Animal[] animals =
        {
            new Bird("Орел"),
            new Fish("Рыбка"),
            new Bird("Синица")
        };

        var flyingAnimals = animals.OfType<ICanFly>();

        Console.WriteLine("Животные, которые умеют летать:");
        foreach (var animal in flyingAnimals)
        {
            animal.Fly();
        }
    }
}

