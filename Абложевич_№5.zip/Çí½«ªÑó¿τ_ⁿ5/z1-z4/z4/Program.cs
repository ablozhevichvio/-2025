﻿using System;

interface ISpeaker
{
    void AdjustVolume(int level);
}

interface IMicrophone
{
    void AdjustVolume(int level);
}

class AudioDevice : ISpeaker, IMicrophone
{
    void ISpeaker.AdjustVolume(int level)
    {
        Console.WriteLine($"Громкость динамика установлена на {level}.");
    }

    void IMicrophone.AdjustVolume(int level)
    {
        Console.WriteLine($"Чувствительность микрофона установлена на {level}.");
    }
}

class Program
{
    static void Main()
    {
        AudioDevice device = new AudioDevice();

        ISpeaker speaker = device;
        IMicrophone microphone = device;

        speaker.AdjustVolume(10);  
        microphone.AdjustVolume(5); 
    }
}
