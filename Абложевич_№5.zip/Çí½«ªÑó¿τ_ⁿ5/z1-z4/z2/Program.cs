﻿using System;

class Wheel
{
    public string Brand { get; set; }
    public Wheel(string brand)
    {
        Brand = brand;
    }
}

class Engine
{
    public string Model { get; set; }
    public Engine(string model)
    {
        Model = model;
    }
}

class Driver
{
    public string Name { get; set; }
    public Driver(string name)
    {
        Name = name;
    }
    public void Drive(Car car)
    {
        Console.WriteLine($"{Name} ведёт {car.Model}");
        car.Drive();
    }
}

class Car
{
    public string Model { get; set; }
    public Wheel[] Wheels { get; set; }
    public Engine Engine { get; } 

    public Car(string model, Wheel[] wheels, string engineModel)
    {
        Model = model;
        Wheels = wheels;
        Engine = new Engine(engineModel);
    }

    public void Drive()
    {
        Console.WriteLine($"{Model} с двигателем {Engine.Model} едет.");
    }
}

class Program
{
    static void Main()
    {
        Wheel[] wheels = { new Wheel("Michelin"), new Wheel("Michelin"), new Wheel("Michelin"), new Wheel("Michelin") };
        Car[] cars =
        {
            new Car("Audi", wheels, "V4"),
            new Car("VV", wheels, "V6")
        };

        Driver driver = new Driver("Володя");

        foreach (var car in cars)
        {
            driver.Drive(car);
        }
    }
}