﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число: ");
        int number = int.Parse(Console.ReadLine());

        long result = MathUtils.Factorial(number);
        Console.WriteLine($"Факториал {number} = {result}");
    }
}

static class MathUtils
{
    public static long Factorial(int n)
    {
        if (n < 0)
            throw new ArgumentException("Факториал определён только для неотрицательных чисел.");

        long fact = 1;
        for (int i = 2; i <= n; i++)
        {
            fact *= i;
        }
        return fact;
    }
}
