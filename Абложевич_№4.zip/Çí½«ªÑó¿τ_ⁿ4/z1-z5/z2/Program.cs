﻿using System;

class Program
{
    static void Main()
    {
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Введите число {i + 1}: ");
            double input = double.Parse(Console.ReadLine());

            double result;
            PowerA3(input, out result);

            Console.WriteLine($"Третья степень числа {input} = {result}");
        }
    }

    static void PowerA3(double A, out double B)
    {
        B = A * A * A;
    }
}

