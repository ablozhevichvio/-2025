﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число для вычисления факториала: ");
        int number;

        if (!int.TryParse(Console.ReadLine(), out number) || number < 0)
        {
            Console.WriteLine("Ошибка: введите неотрицательное целое число.");
            return;
        }

        try
        {
            long result = Factorial(number);
            Console.WriteLine($"Факториал {number} = {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
   
    static long Factorial(int n)
    {
        if (n < 0)
            throw new ArgumentException("Факториал определён только для неотрицательных чисел.");

        if (n == 0 || n == 1)
            return 1; 

        return n * Factorial(n - 1);
    }
}

