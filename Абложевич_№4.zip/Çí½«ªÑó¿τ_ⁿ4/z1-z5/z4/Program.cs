﻿using System;
using System.Linq;

static class StringExtensions
{
  
    public static int CountVowels(this string str)
    {
        if (string.IsNullOrEmpty(str))
            return 0;

        char[] vowels = { 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я'}; 

        return str.ToLower().Count(c => vowels.Contains(c));
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        int vowelCount = input.CountVowels();
        Console.WriteLine($"Количество гласных букв: {vowelCount}");
    }
}

