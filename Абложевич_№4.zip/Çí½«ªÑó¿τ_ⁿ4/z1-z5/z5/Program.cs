﻿using System;

abstract class Shape
{
    public abstract double CalculateArea();


    public virtual void DisplayInfo()
    {
        Console.WriteLine("Это геометрическая фигура.");
    }
}

class Circle : Shape
{
    public double Radius { get; }

    public Circle(double radius)
    {
        Radius = radius;
    }

    public override double CalculateArea()
    {
        return Math.PI * Radius * Radius;
    }
    public override void DisplayInfo()
    {
        Console.WriteLine($"Круг с радиусом {Radius}. Площадь: {CalculateArea():F2}");
    }
}

class Rectangle : Shape
{
    public double Width { get; }
    public double Height { get; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override double CalculateArea()
    {
        return Width * Height;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Прямоугольник {Width}x{Height}. Площадь: {CalculateArea():F2}");
    }
}

class Program
{
    static void Main()
    {
        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(4, 6);

        circle.DisplayInfo();
        rectangle.DisplayInfo();
    }
}
