﻿using System;
using System.Collections.Generic;
using System.Linq;


public interface IRepository<T>
{
    void Add(T item);
    bool Remove(T item);
    IEnumerable<T> GetAll();
}


public class MemoryRepository<T> : IRepository<T>
{
    private List<T> _items = new List<T>();
   
    public void Add(T item)
    {
        _items.Add(item);
    }
    
    public bool Remove(T item)
    {
        return _items.Remove(item);
    }
    
    public IEnumerable<T> GetAll()
    {
        return _items;
    }
}


public class RepositoryManager<T>
{
    private IRepository<T> _repository;
    
    public RepositoryManager(IRepository<T> repository)
    {
        _repository = repository;
    }
    
     public void DisplayAll()
    {
        foreach (var item in _repository.GetAll())
        {
            Console.WriteLine(item);
        }
    }
    
    public T Find(Func<T, bool> predicate)
    {
        return _repository.GetAll().FirstOrDefault(predicate);
    }
}
 

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
    
    public override string ToString()
    {
        return $"Имя: {Name}, Возраст: {Age}";
    }
}


class Program
{
    static void Main()
    {
        IRepository<Person> personRepository = new MemoryRepository<Person>();
        RepositoryManager<Person> manager = new RepositoryManager<Person>(personRepository);

        personRepository.Add(new Person { Name = "Александр", Age = 29 });
        personRepository.Add(new Person { Name = "Марта", Age = 25 });

        Console.WriteLine("Все люди:");
        manager.DisplayAll();

        Console.WriteLine("\nПоиск человека по имени 'Марта':");
        var foundPerson = manager.Find(p => p.Name =="Марта");
        Console.WriteLine(foundPerson != null ? foundPerson.ToString() : "Не найдено");
    }
}
