﻿using System;
using System.Collections;

class Command
{
    public string Description { get; }
    public Action ExecuteAction { get; }
    public Action UndoAction { get; }

    public Command(string description, Action execute, Action undo)
    {
        Description = description;
        ExecuteAction = execute;
        UndoAction = undo;
    }
}

class CommandManager
{
    private Stack executedCommands = new Stack();
    private Stack undoneCommands = new Stack();

    public void Execute(Command command)
    {
        command.ExecuteAction();
        executedCommands.Push(command);
        undoneCommands.Clear();
    }

    public void Undo()
    {
        if (executedCommands.Count > 0)
        {
            Command command = (Command)executedCommands.Pop();
            command.UndoAction();
            undoneCommands.Push(command);
        }
        else
        {
            Console.WriteLine("Отменять нечего!");
        }
    }

    public void Redo()
    {
        if (undoneCommands.Count > 0)
        {
            Command command = (Command)undoneCommands.Pop();
            command.ExecuteAction();
            executedCommands.Push(command);
        }
        else
        {
            Console.WriteLine("Повторять нечего!");
        }
    }
}

class Program
{
    static void Main()
    {
        CommandManager manager = new CommandManager();
        int value = 0;

        Command addCommand = new Command(
            "Добавить 10",
            () => { value += 10; Console.WriteLine("Значение: " + value); },
            () => { value -= 10; Console.WriteLine("Значение: " + value); }
        );

        manager.Execute(addCommand);
        manager.Undo();
        manager.Redo();
    }
}

