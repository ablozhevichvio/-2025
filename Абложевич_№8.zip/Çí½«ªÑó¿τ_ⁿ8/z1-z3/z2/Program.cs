﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Security;

class MyList<T>
{
    private List<T> items = new List<T>();

    public void Add(T item)
    {        
        items.Add(item);  
    }

    public bool Remove(T item)
    {
        return items.Remove(item);
    }

    public T Find(Predicate<T> predicate)
    {
        return items.Find(predicate);
    }

    public void Sort(Comparison<T> comparison)
    {
        items.Sort(comparison);
    }

    public void PrintAll()
    {
        foreach (var item in items)
        {
            Console.WriteLine(item);
        }
    }
}

class ListManager<T>
{
    private MyList<T> myList = new MyList<T>();
    public void AddItem(T item) 
    {
        myList.Add(item);
    }

    public void RemoveItem(T item)
    {
        if (myList.Remove(item))
            Console.WriteLine("Удалено: " + item);
        else
            Console.WriteLine("Элемент не найден!");
    }

    public void FindItem(Predicate<T> predicate)
    {
        var result = myList.Find(predicate);
        Console.WriteLine(result != null ? "Найдено: " + result : "Ничего не найдено");
    }

    public void SortList(Comparison<T> comparison)
    {
        myList.Sort(comparison);
        Console.WriteLine("Список отсортирован.");
    }

    public void PrintList()
    {
        myList.PrintAll();
    }
}

class Program
{
    static void Main()
    {
        ListManager<int> manager = new ListManager<int>();
        manager.AddItem(5);
        manager.AddItem(2);
        manager.AddItem(8);
        manager.PrintList();

        manager.SortList((a, b) => a.CompareTo(b));
        manager.PrintList();

        manager.FindItem(x => x == 2);
        manager.RemoveItem(2);
        manager.PrintList();
    }
}
