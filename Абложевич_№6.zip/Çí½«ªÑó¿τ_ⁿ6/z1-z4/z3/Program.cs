﻿using System;
using System.IO;

delegate void OrderPlacedHandler(string orderInfo);

class OrderManager
{
    public event OrderPlacedHandler OrderPlaced;

    public void PlaceOrder(string orderInfo)
    {
        Console.WriteLine($"Заказ оформлен: {orderInfo}");
        OrderPlaced?.Invoke(orderInfo);
    }
}

class EmailNotifier
{
    public void SendEmail(string orderInfo)
    {
        Console.WriteLine($"Уведомление на email: Ваш заказ '{orderInfo}' оформлен.");
    }
}

class SmsNotifier
{
    private string filePath = @"D:\ПРАКТИКА 2025\Абложевич В.Р. 41-тп(6)\SMS.txt";

    public void SendSms(string orderInfo)
    {
        string message = $"SMS: Ваш заказ '{orderInfo}' подтвержден.";
        Console.WriteLine(message);

        try
        {
            string directoryPath = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            File.AppendAllText(filePath, message + Environment.NewLine);
            Console.WriteLine($"SMS записано в файл: {filePath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при записи SMS в файл: " + ex.Message);
        }
    }
}

class Program
{
    static void Main()
    {
        OrderManager orderManager = new OrderManager();
        EmailNotifier emailNotifier = new EmailNotifier();
        SmsNotifier smsNotifier = new SmsNotifier();

        orderManager.OrderPlaced += emailNotifier.SendEmail;
        orderManager.OrderPlaced += smsNotifier.SendSms;

        Console.Write("Введите информацию о заказе: ");
        string orderInfo = Console.ReadLine();

        orderManager.PlaceOrder(orderInfo);
    }
}
