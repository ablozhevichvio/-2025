﻿using System;

delegate void StringProcessor(string input);

class Program
{
    static void ProcessString(string text, StringProcessor processor)
    {
        processor(text);
    }

    static void ToUpperCase(string text)
    {
        Console.WriteLine("Верхний регистр: " + text.ToUpper());
    }
   
    static void ToLowerCase(string text)
    {
        Console.WriteLine("Нижний регистр: " + text.ToLower());
    }

    static void Main()
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        ProcessString(input, ToUpperCase);
        ProcessString(input, ToLowerCase);
    }
}

