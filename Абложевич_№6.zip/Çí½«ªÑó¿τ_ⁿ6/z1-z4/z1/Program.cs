﻿using System;
using System.IO;

delegate void MessageHandler(string message);

class Program
{
    static string filePath = @"D:\ПРАКТИКА 2025\Абложевич В.Р. 41-тп(6)\log.txt";

    static void PrintToConsole(string message)
    {
        Console.WriteLine("Консоль: " + message);
    }

    static void WriteToFile(string message)
    {
        try
        {
            string directoryPath = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            File.AppendAllText(filePath, message + Environment.NewLine);
            Console.WriteLine($"Сообщение записано в файл: {filePath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка записи в файл: " + ex.Message);
        }
    }

    static void Main()
    {
        MessageHandler handler = PrintToConsole;
        handler += WriteToFile;

        Console.Write("Введите сообщение: ");
        string input = Console.ReadLine();
       
        handler(input);
    }
}

