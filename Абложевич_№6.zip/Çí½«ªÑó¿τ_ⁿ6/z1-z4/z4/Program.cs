﻿using System;
using System.IO;

class OrderEventArgs : EventArgs
{
    public string OrderInfo { get; }

    public OrderEventArgs(string orderInfo)
    {
        OrderInfo = orderInfo;
    }
}

class OrderManager
{
    public event EventHandler<OrderEventArgs> OrderPlaced;

    public void PlaceOrder(string orderInfo)
    {
        Console.WriteLine($"Заказ оформлен: {orderInfo}");
        OrderPlaced?.Invoke(this, new OrderEventArgs(orderInfo));
    }
}
class OrderNotifier
{
    public OrderNotifier(OrderManager orderManager, EmailService emailService, SmsService smsService)
    {
        orderManager.OrderPlaced += emailService.SendEmail;
        orderManager.OrderPlaced += smsService.SendSms;
    }
}

class EmailService
{
    public void SendEmail(object sender, OrderEventArgs e)
    {
        Console.WriteLine($"Email: Ваш заказ '{e.OrderInfo}' оформлен.");
    }
}
class SmsService
{
    private string filePath = @"D:\ПРАКТИКА 2025\Абложевич В.Р. 41-тп(6)\SMS.txt";

    public void SendSms(object sender, OrderEventArgs e)
    {
        string message = $"SMS: Ваш заказ '{e.OrderInfo}' подтвержден.";
        Console.WriteLine(message);

        try
        {
            string directoryPath = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            File.AppendAllText(filePath, message + Environment.NewLine);
            Console.WriteLine($"SMS записано в файл: {filePath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при записи SMS в файл: " + ex.Message);
        }
    }
}

class Program
{
    static void Main()
    {
        OrderManager orderManager = new OrderManager();
        EmailService emailService = new EmailService();
        SmsService smsService = new SmsService();

        OrderNotifier notifier = new OrderNotifier(orderManager, emailService, smsService);

        Console.Write("Введите информацию о заказе: ");
        string orderInfo = Console.ReadLine();

        orderManager.PlaceOrder(orderInfo);
    }
}

