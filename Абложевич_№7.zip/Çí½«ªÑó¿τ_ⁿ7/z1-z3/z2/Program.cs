﻿using System;
using System.IO;

class CustomFileException : Exception
{
    public CustomFileException(string message, Exception innerException)
        : base(message, innerException) { }
}
class FileReader
{
    public static void ReadFile(string path)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("Файл не найден.", path);
        }
    }
}

class FileProcessor
{
    public static void ProcessFile(string path)
    {
        try
        {
            FileReader.ReadFile(path);
        }
        catch (FileNotFoundException ex)
        {
            throw new CustomFileException("Ошибка при обработке файла.", ex);
        }
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Введите путь к файлу: ");
            string path = Console.ReadLine();
            FileProcessor.ProcessFile(path);
            Console.WriteLine("Файл успешно обработан.");
        }
        catch (CustomFileException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
            Console.WriteLine($"Внутреннее исключение: {ex.InnerException?.Message}");
            Console.WriteLine($"Стек вызовов: {ex.StackTrace}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Неожиданная ошибка: {ex.Message}");
        }
    }
}
