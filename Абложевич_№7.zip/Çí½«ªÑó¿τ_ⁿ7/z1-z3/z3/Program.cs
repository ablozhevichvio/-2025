﻿using System;

class AgeRestrictionException : Exception
{
    public AgeRestrictionException() : base("Регистрация доступна только с 18 лет.") { }
    public AgeRestrictionException(string message) : base(message) { }
    public AgeRestrictionException(string message, Exception innerException)
        : base(message, innerException) { }
}

class UserRegistration
{
    public static void RegisterUser(int age)
    {
        if (age < 18)
        {
            throw new AgeRestrictionException("Ошибка: возраст для регистрации должен быть 18 лет или больше.");
        }
        Console.WriteLine("Регистрация успешна!");
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Введите ваш возраст: ");
            int age = int.Parse(Console.ReadLine());
            UserRegistration.RegisterUser(age);
        }
        catch (AgeRestrictionException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Ошибка: Введено некорректное значение возраста.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Неожиданная ошибка: {ex.Message}");
        }
    }
}
