﻿using System;

class InvalidAgeException : Exception
{
    public InvalidAgeException() : base("Возраст должен быть 18 лет или больше.") { }
    public InvalidAgeException(string message) : base(message) { }
    public InvalidAgeException(string message, Exception innerException) : base(message, innerException) { }
}

class UserAgeValidator
{
    public static void ValidateAge(int age)
    {
        if (age < 18)
        {
            throw new InvalidAgeException();
        }
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Введите ваш возраст: ");
            int age = int.Parse(Console.ReadLine());
            UserAgeValidator.ValidateAge(age);
            Console.WriteLine("Возраст корректный.");
        }
        catch (InvalidAgeException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Ошибка: Введено некорректное значение возраста.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Неожиданная ошибка: {ex.Message}");
        }
    }
}

