﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите количество строк: ");
        int n = int.Parse(Console.ReadLine());

        int[][] jaggedArray = new int[n][];

        Random rand = new Random();
        for (int i = 0; i < n; i++)
        {
            jaggedArray[i] = new int[rand.Next(2, 6)]; 
        }

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                jaggedArray[i][j] = rand.Next(1, 10);
            }
        }

        for (int i = 0; i < n; i++)
        {
            int sum = 0;
            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                sum += jaggedArray[i][j];
            }

            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                jaggedArray[i][j] = sum;
            }
        }

        Console.WriteLine("\nСтупенчатый массив:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < jaggedArray[i].Length; j++)
            {
                Console.Write(jaggedArray[i][j] + "\t");
            }
            Console.WriteLine();
        }
    }
}

