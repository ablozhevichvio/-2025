﻿using System;

class Program
{
    static void Main()
    {
        int[,] array = {
            { 2, 5, 3 },
            { 4, 10, 6 },
            { 1, 4, 8 }
        };

        int rows = array.GetLength(0);
        int product = 1;

        for (int i = 0; i < rows; i++)
        {
            product *= array[i, 1];
        }

        Console.WriteLine($"Произведение элементов второго столбца: {product}");

        if (product >= 100 && product <= 999)
            Console.WriteLine("Произведение является трёхзначным числом.");
        else
            Console.WriteLine("Произведение НЕ является трёхзначным числом.");
    }
}

