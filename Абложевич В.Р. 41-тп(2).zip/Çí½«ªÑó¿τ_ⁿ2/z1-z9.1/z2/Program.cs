﻿using System;

class Program
{
    static void Main()
    {
        int[] array = new int[100];
        Random rand = new Random();

        for (int i = 0; i < array.Length; i++)
        {
            array[i] = rand.Next(1, 1001);
        }
        Array.Sort(array);

        Console.Write("Введите число для поиска: ");
        int k = int.Parse(Console.ReadLine());

        int index = Array.BinarySearch(array, k);
        Console.WriteLine(index >= 0 ? $"Число {k} найдено в позиции {index}" : "Число не найдено");

        Console.WriteLine("\nМассив в обратном порядке:");
        for (int i = array.Length - 1; i >= 0; i--)
        {
            Console.Write(array[i] + "\t");
            if ((array.Length - i) % 6 == 0) Console.WriteLine();
        }
    }
}
