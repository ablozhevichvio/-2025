﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        bool isOnlyDigits = Regex.IsMatch(input, @"^\d+$");

        if (isOnlyDigits)
            Console.WriteLine("Строка содержит только цифры.");
        else
            Console.WriteLine("Строка содержит не только цифры");
    }
}

