﻿using System;
using System.Text;

class Program
{
    static void Main()
    {
        Console.Write("Введите основную строку: ");
        StringBuilder sb = new StringBuilder(Console.ReadLine());

        Console.Write("Введите строку, которую нужно добавить в начало: ");
        string newText = Console.ReadLine();

        sb.Insert(0, newText + " "); 

        Console.WriteLine($"Результат: {sb}");
    }
}
