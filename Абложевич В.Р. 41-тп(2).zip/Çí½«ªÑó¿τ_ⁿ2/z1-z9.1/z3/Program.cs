﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите N (N < 10): ");
        int n = int.Parse(Console.ReadLine());

        Console.Write("Введите нижнюю границу a: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Введите верхнюю границу b: ");
        int b = int.Parse(Console.ReadLine());

        int[,] matrix = new int[n, n];
        Random rand = new Random();
        int positiveCount = 0;

        Console.WriteLine("\nИсходная матрица:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                matrix[i, j] = rand.Next(a, b + 1);
                Console.Write(matrix[i, j] + "\t");

                if (matrix[i, j] > 0)
                    positiveCount++;
            }
            Console.WriteLine();
        }

        Console.WriteLine($"\nКоличество положительных чисел: {positiveCount}");

        Console.WriteLine("\nСумма элементов каждой строки:");
        for (int i = 0; i < n; i++)
        {
            int sum = 0;
            for (int j = 0; j < n; j++)
            {
                sum += matrix[i, j];
            }
            Console.WriteLine($"Строка {i + 1}: {sum}");
        }
    }
}

