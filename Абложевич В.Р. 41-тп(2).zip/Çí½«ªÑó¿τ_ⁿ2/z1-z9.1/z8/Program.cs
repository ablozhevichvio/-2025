﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        string cleaned = new string(input.Where(char.IsLetterOrDigit).ToArray()).ToLower();

        string reversed = new string(cleaned.Reverse().ToArray());

        if (cleaned == reversed)
            Console.WriteLine("Строка является палиндромом.");
        else
            Console.WriteLine("Строка не является палиндромом.");
    }
}
