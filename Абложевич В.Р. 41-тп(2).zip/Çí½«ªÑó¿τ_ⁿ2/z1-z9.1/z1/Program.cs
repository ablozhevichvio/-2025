﻿using System;

class Program
{
    static void Main()
    {
        int[] array = { 3, 7, 1, 9, 12, 5, 8, 14, 6, 4, 2, 10, 11, 13, 15 };

        int maxIndex = 0;
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > array[maxIndex])
            {
                maxIndex = i;
            }
        }

        int temp = array[0];
        array[0] = array[maxIndex];
        array[maxIndex] = temp;

        Console.WriteLine("Массив после замены:");
        foreach (int num in array)
        {
            Console.Write(num + " ");
        }
    }
}

