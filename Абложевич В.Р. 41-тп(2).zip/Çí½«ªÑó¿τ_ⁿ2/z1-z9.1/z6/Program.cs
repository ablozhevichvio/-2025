﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine().ToLower(); 

        int vowelsCount = 0, consonantsCount = 0;
        string vowels = "аеёиоуыэюя"; 
        string consonants = "бвгджзйклмнпрстфхцчшщ"; 

        foreach (char c in input)
        {
            if (vowels.Contains(c)) vowelsCount++;
            else if (consonants.Contains(c)) consonantsCount++;
        }

        Console.WriteLine($"Гласных: {vowelsCount}");
        Console.WriteLine($"Согласных: {consonantsCount}");
    }
}
