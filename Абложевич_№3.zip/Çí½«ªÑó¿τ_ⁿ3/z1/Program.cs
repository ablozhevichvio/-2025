﻿using System;

class A
{
    private int a;
    private int b;

    public A(int a, int b)
    {
        this.a = a;
        this.b = b;
    }

    public int Sum()
    {
        return a + b;
    }

    public double CalculateExpression()
    {
        if (a == 0) 
        {
            Console.WriteLine("Ошибка: деление на ноль.");
            return double.NaN; 
        }
        return Math.Sin(b) / (3 * a);
    }

    public void DisplayValues()
    {
        Console.WriteLine($"a = {a}, b = {b}");
    }
}

class Program
{
    static void Main()
    {
        A obj = new A(2, 30);

        obj.DisplayValues();
        Console.WriteLine("Сумма: " + obj.Sum());
        Console.WriteLine("Результат выражения: " + obj.CalculateExpression());
    }
}
