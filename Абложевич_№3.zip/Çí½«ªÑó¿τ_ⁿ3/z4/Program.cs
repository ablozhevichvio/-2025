﻿using System;
using System.Linq;

public partial class Student
{
    public string Name { get; }
    public string Group { get; }
    public double GPA { get; } 

    public Student(string name, string group, double gpa)
    {
        Name = name;
        Group = group;
        GPA = gpa;
    }
}

public partial class Student
{
    public void DisplayInfo()
    {
        Console.WriteLine($"Имя: {Name}, Группа: {Group}, Средний балл: {GPA:F2}");
    }
}

class University
{
    private Student[] students;

    public University(Student[] students)
    {
        this.students = students;
    }

    public Student[] GetTopStudents()
    {
        return students.Where(s => s.GPA > 4.5).ToArray();
    }

    public Student[] GetStudentsByGroup(string group)
    {
        return students.Where(s => s.Group == group).ToArray();
    }
}

class Program
{
    static void Main()
    {
        Student[] students =
        {
            new Student("Евменова София", "41-тп", 7.8),
            new Student("Плотникова Ксения", "41-тп", 7.9),
            new Student("Иванов Иван", "40-тп", 8.5),
            new Student("Петров Максим", "39-тп", 8.7)
        };

        University university = new University(students);

        Console.WriteLine("Лучшие студенты:");
        foreach (var student in university.GetTopStudents())
        {
            student.DisplayInfo();
        }

        Console.WriteLine("\nСтуденты группы 41-тп:");
        foreach (var student in university.GetStudentsByGroup("41-тп"))
        {
            student.DisplayInfo();
        }
    }
}
