﻿using System;
using System.Linq;

class Person
{
    public string Name { get; set; }
    public int Age { get; set; }

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }
}

static class ArrayUtils
{
    public static int GetMaxValue(Person[] people)
    {
        if (people == null || people.Length == 0)
        {
            Console.WriteLine("Ошибка: массив пуст или не задан.");
            return -1; 
        }

        return people.Max(p => p.Age);
    }
}

class Program
{
    static void Main()
    {
        
        Person[] people =
        {
            new Person("Соня", 19),
            new Person("Мария", 21),
            new Person("Полина", 22),
            new Person("Яна", 24)
        };

        int maxAge = ArrayUtils.GetMaxValue(people);

        Console.WriteLine("Максимальный возраст: " + maxAge);
    }
}
