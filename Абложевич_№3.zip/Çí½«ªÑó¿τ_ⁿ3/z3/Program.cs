﻿using System;
using System.Linq;

abstract class Transport
{
    public string Model { get; }
    public int MaxSpeed { get; }
    public double FuelConsumption { get; } 

    protected Transport(string model, int maxSpeed, double fuelConsumption)
    {
        Model = model;
        MaxSpeed = maxSpeed;
        FuelConsumption = fuelConsumption;
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"Модель: {Model}, Макс. скорость: {MaxSpeed} км/ч, Расход топлива: {FuelConsumption} л/100км");
    }
}

sealed class Car : Transport
{
    public Car(string model, int maxSpeed, double fuelConsumption)
        : base(model, maxSpeed, fuelConsumption) { }
}

sealed class Truck : Transport
{
    public Truck(string model, int maxSpeed, double fuelConsumption)
        : base(model, maxSpeed, fuelConsumption) { }
}

class TransportManager
{
    private Transport[] vehicles;

    public TransportManager(Transport[] vehicles)
    {
        this.vehicles = vehicles;
    }

    public Transport GetMostEfficientVehicle()
    {
        return vehicles.OrderBy(v => v.FuelConsumption).FirstOrDefault();
    }

    public Transport GetFastestVehicle()
    {
        return vehicles.OrderByDescending(v => v.MaxSpeed).FirstOrDefault();
    }
}

class Program
{
    static void Main()
    {
        Transport[] vehicles =
        {
            new Car("Volkswagen Golf", 203, 4.3),
            new Truck("Volvo FH16", 140, 25),
            new Car("SSC Tuatara", 509, 20),
            new Truck("Scania R500", 130, 30)
        };

        TransportManager manager = new TransportManager(vehicles);

        Transport efficientVehicle = manager.GetMostEfficientVehicle();
        Console.WriteLine("Самый экономичный транспорт:");
        efficientVehicle?.DisplayInfo();

        Transport fastestVehicle = manager.GetFastestVehicle();
        Console.WriteLine("\nСамый быстрый транспорт:");
        fastestVehicle?.DisplayInfo();
    }
}
